package com.example.tabs;

public class Photos {
    private int Id;
    private int Album;
    private String Title;
    private String Url;
    private String ThumbnailUrl;

    public int getId() {
        return Id;
    }

    public int getAlbum() {
        return Album;
    }

    public String getTitle() {
        return Title;
    }

    public String getUrl() {
        return Url;
    }

    public String getThumbnailUrl(){ return ThumbnailUrl; }

}
