package com.example.tabs;


public class Post {
    private int userId;
    private int id;
    private String title;

    public int getUserId() {
        return userId;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }
}
