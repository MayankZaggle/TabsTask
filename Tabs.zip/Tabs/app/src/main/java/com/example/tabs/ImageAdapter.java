package com.example.tabs;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

import retrofit2.Callback;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.UserViewHolder> {
    private List<Photos> mPhotoList;
    private Context context;
    // public void UserAdapter(){}
    public ImageAdapter(){
        mPhotoList=null;
        context=null;

    }
    public void setData(List<Photos> photoList){

        mPhotoList=photoList;
       // this.context=context;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.row_image_layout,parent,false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        Photos photos = mPhotoList.get(position);
       // String url= photos.getUrl();
        int id=photos.getId();
        int album = photos.getAlbum();
        String title=photos.getTitle();
        holder.album.setText(""+album);
        holder.title.setText(title);
        holder.id.setText(""+id);
        Picasso.with(holder.itemView.getContext()).load(photos.getUrl())
                .into(holder.pic);
    }

    @Override
    public int getItemCount() {
        return mPhotoList.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder{
        ImageView pic;
        TextView id;
        TextView album;
        TextView title;
        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            title=(TextView) itemView.findViewById(R.id.textView6);
            album=(TextView) itemView.findViewById(R.id.textView7);
            id = (TextView) itemView.findViewById(R.id.textView8);
            pic= (ImageView)itemView.findViewById(R.id.imageView);

        }
    }
}
